<?php

$apikey = "b490be7d0911c6faccb16511aa497c6a";

$imgurl_1 = "http://image.tmdb.org/t/p/w500";
$imgurl_2 = "http://image.tmdb.org/t/p/w300";

?>