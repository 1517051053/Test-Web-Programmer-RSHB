# Website Update Film dan TV Series Terbaru dengan PHP dan The Movie Database API

Aplikasi Web yang menyediakan informasi terbaru film dan tv series dengan PHP dan API TMDB

## Video Tutorial Step by Step Membuat SI Update Film TV dengan API TMDB
Ikuti penjelasan tiap baris kode di [Video ini](https://www.youtube.com/watch?v=8WoiNo7O5iw) via **YouTube**

## Subscribe Channel JuniorDev

[Junior Dev](https://www.youtube.com/c/juniordevindonesia) adalah sebuah channel tutorial komputer dan programmer mulai dari *HTML, CSS, PHP, SQL, Angular, Web Design* dan sebagainya. Di channel ini kamu bisa dapatkan tutorial gratis yang selalu update. Subscribe dan Like channel ini agar kamu bisa mengikuti terus tutorial-tutorialnya.

Jangan lupa follow untuk kontak, bertanya dan berdiskusi
* [Channel Youtube](https://www.youtube.com/c/juniordevindonesia)
* [Like Fanpage](https://www.facebook.com/juniordevindonesiaofficial/)
* [Twitter](http://twitter.com/hello_juniordev)
* [Instagram](https://www.instagram.com/juniordevindonesia/)
* [Google Plus](https://plus.google.com/+JuniorDevIndonesia/posts)
* [Email](mailto:hellojuniordev@gmail.com)

Jangan lupa [**SUBSCRIBE**](https://www.youtube.com/c/juniordevindonesia?sub_confirmation=1) ya..!

## Author
* **Sofyan Setiawan** - *Freelance Web Designer and Developer* - [Facebook](https://www.facebook.com/sofyansetiawanprofile) - [@sofyansetiawann](https://twitter.com/sofyansetiawann)